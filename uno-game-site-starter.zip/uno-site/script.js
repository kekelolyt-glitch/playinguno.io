const ADMIN_PASSWORD = "forleak12"; // Demo only: visible to anyone viewing the source.
const defaults = {
  title: "EVERY TABLE HAS A SURPRISE",
  description: "Discover UNO gameplay on Windows PC. Match colors and numbers, play action cards at just the right moment, and call UNO when only one card remains.",
  download: "",
  trailer: "",
  email: "support@example.com"
};
const $ = (s) => document.querySelector(s);
const loginModal = $("#loginModal"), adminModal = $("#adminModal");
const settingsForm = $("#settingsForm");

function readSettings() {
  try { return {...defaults, ...JSON.parse(localStorage.getItem("unoSiteSettings") || "{}")}; }
  catch { return {...defaults}; }
}
function applySettings(data) {
  const title = data.title || defaults.title;
  const split = title.toUpperCase().split(" ");
  const firstLine = split.slice(0, Math.max(1, Math.ceil(split.length/2))).join(" ");
  const secondLine = split.slice(Math.max(1, Math.ceil(split.length/2))).join(" ");
  $(".hero h1").innerHTML = `${escapeHtml(firstLine)}<br><em>${escapeHtml(secondLine)}</em>`;
  $(".intro").textContent = data.description || defaults.description;
  const download = $("#downloadLink");
  download.href = safeUrl(data.download) || "#";
  $("#downloadNote").textContent = data.download ? "Download link is ready." : "Download link will be announced soon.";
  $("#trailerLink").href = safeUrl(data.trailer) || "#";
  $("#trailerLink").querySelector("span:last-child").textContent = data.trailer ? "WATCH THE OFFICIAL TRAILER" : "ADD YOUR GAME TRAILER LINK IN ADMIN SETTINGS";
  $("#supportLink").href = data.email ? `mailto:${data.email}` : "mailto:support@example.com";
}
function safeUrl(value) {
  try { const u = new URL(value); return ["https:","http:"].includes(u.protocol) ? u.href : ""; } catch { return ""; }
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function openLogin(){loginModal.hidden=false;$("#adminPassword").focus();}
function closeModals(){loginModal.hidden=true;adminModal.hidden=true;}
$("#secretTrigger").addEventListener("click",openLogin);
document.addEventListener("keydown",e=>{if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==="a"){e.preventDefault();openLogin();}if(e.key==="Escape")closeModals();});
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",closeModals));
[loginModal,adminModal].forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModals();}));
$("#loginForm").addEventListener("submit",e=>{
  e.preventDefault();
  if($("#adminPassword").value===ADMIN_PASSWORD){
    loginModal.hidden=true;adminModal.hidden=false;$("#loginError").textContent="";
    const d=readSettings();Object.keys(defaults).forEach(k=>settingsForm.elements[k].value=d[k]||"");
  }else{$("#loginError").textContent="Wrong password. Try again.";}
});
settingsForm.addEventListener("submit",e=>{
  e.preventDefault();const data={};Object.keys(defaults).forEach(k=>data[k]=settingsForm.elements[k].value.trim());
  localStorage.setItem("unoSiteSettings",JSON.stringify(data));applySettings(data);$("#saveMessage").textContent="Saved in this browser.";
});
$("#resetSettings").addEventListener("click",()=>{localStorage.removeItem("unoSiteSettings");applySettings(defaults);Object.keys(defaults).forEach(k=>settingsForm.elements[k].value=defaults[k]);$("#saveMessage").textContent="Settings reset in this browser.";});
$("#menuToggle").addEventListener("click",()=>$("#nav").classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>$("#nav").classList.remove("open")));
$("#year").textContent=new Date().getFullYear();
applySettings(readSettings());
