# UNO fan/game project website starter

## GitHub Pages'e yükleme
1. ZIP dosyasını bilgisayarında çıkar.
2. GitHub'da yeni bir repository oluştur (ör. `uno-game-site`).
3. `index.html`, `style.css`, `script.js` ve `assets` klasörünü repository'nin ana dizinine yükle.
4. Repository > Settings > Pages bölümüne gir.
5. **Deploy from a branch** seç; branch olarak `main`, klasör olarak `/ (root)` seç ve Save'e bas.
6. Birkaç dakika sonra GitHub Pages adresin yayınlanır.

## Görseller
`assets/uno-bg.jpg` senin gönderdiğin UNO arka plan görselidir. Başka görsel kullanmak istersen aynı dosya adıyla değiştirebilirsin.

## Demo admin paneli
- Gizli erişim: sayfanın sağ alt köşesindeki çok zor görünen noktaya tıkla veya `Ctrl + Shift + A` tuşlarına bas.
- Demo şifresi: `forleak12`
- Başlık, açıklama, indirme URL'si, trailer URL'si ve destek e-postası değiştirilebilir.
- ÖNEMLİ: Bu demo paneli sadece açık olan tarayıcıda localStorage'a kaydeder; siteyi ziyaret eden herkese değişiklik yayınlamaz. Şifre de JavaScript dosyasında görünür. Gerçek, güvenli ve herkese yansıyan yönetim için Supabase/Firebase gibi backend + authentication gerekir. Gerçek şifreyi bu statik sürümde kullanma.

## Yayına almadan önce
- `script.js` içindeki demo şifresini gerçek bir güvenlik yöntemiyle değiştirmeden public siteye hassas bilgi koyma.
- İndirme butonuna kendi oyununun güvenilir Windows kurulum dosyası bağlantısını ekle.
- Trailer ve destek e-postasını kendine göre güncelle.
- UNO/Mattel markası ve görsellerinin kullanım haklarını kontrol et; kendi oyununun adını/logosunu kullanman gerekiyorsa değiştir.
